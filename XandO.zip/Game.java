import java.awt.Color;

public class Game
{

Color black = new Color(0 , 0 , 0);
Color gray  = new Color(100,100,100);
Color white = new Color(255,255,255);
Color blue  = new Color(0 , 0 ,255);
Color red   = new Color(255, 0 , 0);
Color green = new Color(0 , 255 , 0);
private double[] pos = { -166.67,166.67, 0.0,166.67 , 166.67,166.67 , -166.67,0.0 , 0.0,0.0 , 166.67,0.0 ,  -166.67,-166.67, 0.0,-166.67 , 166.67,-166.67 };  
private String[] str =  {"a" , "b" , "c" , "d" , "e" , "f" , "g" , "h" , "i"};

int k = 0;
 int counter = 0;
 int Xcounter = 0;
 int Ocounter = 0;
 int[] Xps = {0 , 0 , 0 ,0 };
 int[] Ops = {0 , 0 , 0 , 0 ,0 };

MyAudio player1   = new MyAudio();
MyAudio player2   = new MyAudio();
MyAudio draw      = new MyAudio();


public Game()
{



}



public void CleanCanvas()
{     

	k  = 0;
	counter = 0;
	Xcounter= 0;
	Ocounter=0;

	for(int p = 0 ; p < Xps.length ; p++)
	{
Xps[p] = 11;
	}
	for(int u = 0 ; u < Ops.length ; u++)
	{
Ops[u] = 11;
	}

double radius = StdDraw.getPenRadius();
StdDraw.enableDoubleBuffering();
StdDraw.setXscale(-500 , 500);
StdDraw.setYscale(-500 , 500);
StdDraw.clear(gray);
StdDraw.setPenColor(white);
StdDraw.filledSquare(0 , 0 ,250);
StdDraw.setPenColor(black);
StdDraw.line(-83.33,250,-83.33,-250);
StdDraw.line(83.33,250,83.33,-250);
StdDraw.line(-250,83.33,250,83.33);
StdDraw.line(-250,-83.33 , 250 , -83.33);

StdDraw.setPenRadius(0.001);

for(int i = 0 ; i <9 ; i++)
{

StdDraw.text(pos[i*2] , pos[(i*2)+1] ,str[i] );


}
StdDraw.setPenRadius(0.005);
StdDraw.text(-270,400,"The First Player will be assigned :");
StdDraw.setPenColor(blue);
StdDraw.text(0 , 400 ,"O");
StdDraw.setPenColor(black);
StdDraw.text(-125,350,"Press the Letter that represents your desired position");
StdDraw.text(-300,-310,"To Quit The Game Press : Q");
StdDraw.text(-300,-360,"To Mute The Game Press : M");
StdDraw.text(-350,-410,"To Restart Press   : R");
StdDraw.show();
play();


}

public void play()
{


char[] check = {'1','2','3','4','5','6','7','8','9','1'};



while(true)
{

	if(StdDraw.isKeyPressed('R'))
	{
CleanCanvas();
	}

if(StdDraw.isKeyPressed('A'))
{
test(0,'A',check);
}

if(StdDraw.isKeyPressed('B'))
{
test(1,'B',check);
}


if(StdDraw.isKeyPressed('C'))
{
test(2,'C',check);
}

if(StdDraw.isKeyPressed('D'))
{
test(3,'D',check);
}

if(StdDraw.isKeyPressed('E'))
{
test(4,'E',check);
}
if(StdDraw.isKeyPressed('F'))
{
test(5,'F',check);
}
if(StdDraw.isKeyPressed('G'))
{
test(6,'G',check);
}
if(StdDraw.isKeyPressed('H'))
{
test(7,'H',check);
}

if(StdDraw.isKeyPressed('I'))
{
test(8,'I',check);
}


if(StdDraw.isKeyPressed('Q'))
{break;
}



}
}

public void test(int index , char chara , char[] check)
{
if( check[index] == chara)
{
del(chara , 0,index,check);
}
else{

del(chara , 1,index,check);
}

}

public void del(char ch , int what,int index,char[] check)

{

	if( what == 0 )   //position ch is taken
	{
          //no increment to counter;
         //no window clearing
	}

    else {
          
           check[index] = ch;
           StdDraw.setPenColor(white);
	   StdDraw.filledSquare(pos[index*2] , pos[(index*2) +1] , 50);
           puts(counter,index); //print an X or O based on counter;
	   ++counter;
    }



}

public void puts(int counter , int index )
{



if( counter %2 == 0 )
{
Ops[Ocounter] = index + 1;

StdDraw.setPenColor(blue);
StdDraw.text(pos[index * 2] , pos[(index*2) +1] ,"O");
StdDraw.show();
++Ocounter;
}

if(counter %2 != 0 ) {

Xps[Xcounter] = index +1;

StdDraw.setPenColor(red);
StdDraw.text(pos[index *2 ] , pos[(index*2)+1] ,"X");
StdDraw.show();
++Xcounter;

}

if(counter > 3 )
{
	for(int i : Ops)
	{
System.out.print(i + " ");

	}
System.out.println(" ");
win(Ops , Xps , counter);
System.out.println("win is called");
}



if ( counter  > 7 )
{
winner(3); // Its a Draw
}






}

public void win(int[] Ops , int[] Xps , int counter)
{

int stoper = 0;
int chk    = 0;
int chk1   = 0;
int chk2   = 0;
int sum    = 0;
//Testing For Scenario one "Function" , if it fails we call "Function1" which checks another scenario etc..
//I don't actually need function bubble , because the data is small and i can easily perform a linear search;
//O will represent false and one will represent true;



for( int i = 0 ; i < 1 ; i++ )  //This is Function0  ( we are looking for 1 , 2 ,3); in Ops
{
chk = search(1,Ops);
chk1 = search(2,Ops);
chk2 = search(3,Ops);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Ops won
{
winner(0);
//write function won " That will display winner and clean CAnvas

}

chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function0  ( we are looking for 1 , 2 ,3); in Xps
{
chk = search(1,Xps);
chk1 = search(2,Xps);
chk2 = search(3,Xps);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Xps won
{
winner(1);
//write function won " That will display winner and clean CAnvas

}


chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function0  ( we are looking for 4 , 5 ,6); in Ops
{
chk = search(4,Ops);
chk1 = search(5,Ops);
chk2 = search(6,Ops);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Ops won
{
winner(0);
//write function won " That will display winner and clean CAnvas

}





chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function0  ( we are looking for 4 , 5 ,6); in Xps
{
chk = search(4,Xps);
chk1 = search(5,Xps);
chk2 = search(6,Xps);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Xps won
{
winner(1);
//write function won " That will display winner and clean CAnvas

}


chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function0  ( we are looking for 7 , 8 ,9); in Ops
{
chk = search(7,Ops);
chk1 = search(8,Ops);
chk2 = search(9,Ops);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Xps won
{
winner(0);
//write function won " That will display winner and clean CAnvas

}




chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function0  ( we are looking for 7 , 8 ,9); in Xps
{
chk = search(7,Xps);
chk1 = search(8,Xps);
chk2 = search(9,Xps);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Xps won
{
winner(1);
//write function won " That will display winner and clean CAnvas

}



// This is Scenario 2 

chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function2  ( we are looking for 1 ,4 ,7); in Ops
{
chk = search(7,Ops);
chk1 = search(1,Ops);
chk2 = search(4,Ops);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Ops won
{
winner(0);
//write function won " That will display winner and clean CAnvas

}




chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function2  ( we are looking for 1 , 4 ,7); in Xps
{
chk = search(7,Xps);
chk1 = search(4,Xps);
chk2 = search(1,Xps);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Xps won
{
winner(1);
//write function won " That will display winner and clean CAnvas

}



chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function2  ( we are looking for 2 , 5 ,8); in Ops
{
chk = search(2,Ops);
chk1 = search(8,Ops);
chk2 = search(5,Ops);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Ops won
{
winner(0);
//write function won " That will display winner and clean CAnvas

}



chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function2  ( we are looking for 2 , 5 ,8); in Xps
{
chk = search(2,Xps);
chk1 = search(8,Xps);
chk2 = search(5,Xps);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Xps won
{
winner(1);
//write function winner " That will display winner and clean CAnvas

}




chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function2  ( we are looking for 3 , 6 ,9); in Ops
{
chk = search(3,Ops);
chk1 = search(6,Ops);
chk2 = search(9,Ops);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Ops won
{
winner(0);
//write function won " That will display winner and clean CAnvas

}




chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function2  ( we are looking for 3 , 6 ,9); in Xps
{
chk = search(3,Xps);
chk1 = search(6,Xps);
chk2 = search(9,Xps);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Xps won
{
winner(1);
//write function won " That will display winner and clean CAnvas

}





//This is Function 3 


chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function3  ( we are looking for 1 , 5 ,9); in Ops
{
chk = search(1,Ops);
chk1 = search(5,Ops);
chk2 = search(9,Ops);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Ops won
{
winner(0);
//write function won " That will display winner and clean CAnvas

}





chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function3  ( we are looking for 1, 5 ,9); in Xps
{
chk = search(1,Xps);
chk1 = search(5,Xps);
chk2 = search(9,Xps);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Xps won
{
winner(1);
//write function won " That will display winner and clean CAnvas

}








chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function3  ( we are looking for 7 , 5 ,3); in Ops
{
chk = search(7,Ops);
chk1 = search(5,Ops);
chk2 = search(3,Ops);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Ops won
{
winner(0);
//write function won " That will display winner and clean CAnvas

}







chk = 0;
chk2 = 0;
chk1 = 0;


for( int i = 0 ; i < 1 ; i++ )  //This is Function0  ( we are looking for 7 , 5 ,3); in Xps
{
chk = search(7,Xps);
chk1 = search(5,Xps);
chk2 = search(3,Xps);

}
sum = chk + chk1 + chk2 ;
if( sum == 3 )    //Xps won
{
winner(1);
//write function won " That will display winner and clean CAnvas

}




//Done with winning Functions Now we do Draw






}


public void bubble(int[] Ops , int[] Xps)
{
  int temp = 0;

  for( int i = 0 ; i < Ops.length ; i++)
  {

for(int  j = 0 ; j < (Ops.length -1 ) ; j++)
{

if( Ops[j] > Ops[j+1])
{
temp = Ops[j];
Ops[j] = Ops[j+1];
Ops[j+1] = temp;

}



}



  }

  for( int i = 0 ; i < Xps.length ; i++)
  {

for(int  j = 0 ; j < (Xps.length -1 ) ; j++)
{

if( Xps[j] > Xps[j+1])
{
temp = Xps[j];
Xps[j] = Xps[j+1];
Xps[j+1] = temp;

}



}



  }


}

public int search(int value , int[] dataSet)
{
int BREAK = 0;
int cnter = 0;
int index = 0;
	while( true)
	{
	   
	   if(index >= dataSet.length )
	   { cnter = 0;
              break;
	   }

	   if( value == dataSet[index] )
	   {
cnter = 1;
break;
	   }

	   else {
++index;
	   }

 
         	}





return cnter;

}

public void winner(int ps  )	
{
StdDraw.clear(white);

if( ps == 0 ) //Ops won
{
StdDraw.setPenColor(blue);
StdDraw.text(0 , 0 , " Player 1  ( O ) Won " );

for(int i = 0  ; i < 3 ; i++)
{

player1.win1();

}

}

if(ps == 1) {
StdDraw.setPenColor(red);
StdDraw.text(0 , 0 , " Player 2  ( X ) Won " );

for(int i = 0 ; i < 3 ; i++)
{

player2.win2();
}


}
if( ps == 3 )
{
StdDraw.setPenColor(green);
StdDraw.text(0,0,"Its A Draw");

for(int i = 0 ; i < 3 ; i++)
{

draw.Draw();
}

}

StdDraw.show();
StdDraw.pause(2000);
CleanCanvas();

}



}
