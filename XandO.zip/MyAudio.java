public class MyAudio
{




public MyAudio()   //Clean Constructor;
{

}


public void aka()
{

StdAudio.loop("akaX.wav");
}


public void win1()
{
StdAudio.play("Win1.wav");

}

public void win2()
{
StdAudio.play("Win2.wav");

}

public void Draw()
{
StdAudio.play("Draw.wav");

}



public static void main(String[] args)   //Test Client
{


MyAudio player   = new MyAudio();
MyAudio player1  = new MyAudio();
MyAudio player2  = new MyAudio();

player.aka();
StdAudio.close();
player1.win1();





}



}
