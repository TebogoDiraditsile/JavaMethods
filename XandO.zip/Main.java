import java.util.Scanner;
import java.awt.Color;

public class Main
{


public static void main(String[] args)
{

mainpage();


}

public static void mainpage()
{
boolean state;

StdDraw.enableDoubleBuffering();

Color gray = new Color(100 , 100 , 100);
Color white = new Color(255 , 255 , 255);
Color black = new Color(0 , 0 , 0);
Game  game = new Game();
MyAudio mainSound = new MyAudio();


StdDraw.setCanvasSize(700 , 550);
StdDraw.setXscale(-1000,1000);
StdDraw.setYscale(-1000,1000);
StdDraw.clear(gray);
StdDraw.text(0,900 ,"Welcome To X and O");
StdDraw.picture(0,0,"EntryPage.png",512,512);
StdDraw.text(-500,-700,"To Start Press S");
StdDraw.text(-500,-800,"To Quit  Press Q");
StdDraw.text(-400,-900,"To Enable/Disable Music press M");
StdDraw.show();

mainSound.aka();

while(true)
{
	if( StdDraw.isKeyPressed('Q') )
	{  StdAudio.close();
	   StdDraw.enableDoubleBuffering();
           StdDraw.clear(black);
	   StdDraw.setPenColor(white);
	   StdDraw.text(0,0,"GoodBye");
	   StdDraw.show();
	   StdDraw.pause(500);
	   System.exit(0);
	   
	}
       
	if(StdDraw.isKeyPressed('S'))
	{

        game.CleanCanvas();
       
           

	}


	if( StdDraw.isKeyPressed('M'))
	{

        StdAudio.close();
	StdAudio.close();
	StdAudio.close();


	}


		


}




}





}
