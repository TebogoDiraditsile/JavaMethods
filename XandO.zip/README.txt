TO RUN THE GAME :

1) Extract the zip file.

2) Click/Run  the  windows batch file named "Run"

3) That should run the game.

.............................................................................

Help :
 
 * If the game does not run make sure you have the Java JRE installed.

 * Make sure you have all the game components.
 
 *If the batch file does not run, the main java class is in the Main class.
  So you may run that class to run the game.
 
 * If you are still having problems contact me at sgukha8@gmail.com