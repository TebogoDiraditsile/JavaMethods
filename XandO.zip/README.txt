TO RUN THE GAME :

1) Extract the zip file.

2) Open cmd/terminal  and go to the directory of the game.
eg :  Lets say the game is in Desktop type this : cd Desktop/"XandO"

3) if all is well, run the java file Main in cmd/terminal

eg :  java Main

4) After you type java Main in cmd/terminal the game should run.
     
.............................................................................
 
 * If the game does not run make sure you have JRE installed.

 * Make sure you have all the game components.
 
 * If you are still having problems contact me at sgukha8@gmail.com